# app/domains/catalog/usecases/categories/update_category_mapping.py
"""
UseCase para mapear uma categoria Genesys para PrestaShop.
"""

from __future__ import annotations

from datetime import datetime, UTC

from app.infra.uow import UoW
from app.core.errors import NotFound
from app.models.category import Category
from app.schemas.categories import CategoryMappingOut
from app.domains.audit.services.audit_service import AuditService


def execute(
    uow: UoW,
    *,
    id_category: int,
    id_ps_category: int,
    ps_category_name: str,
    auto_import: bool,
    default_ecotax: float | None = None,
    default_extra_fees: float | None = None,
) -> CategoryMappingOut:
    """
    Mapeia uma categoria Genesys para uma categoria PrestaShop.

    Quando auto_import é ativado, define auto_import_since com a data atual
    para que apenas produtos criados a partir desse momento sejam auto-importados.

    Args:
        default_ecotax: Ecotax default para produtos desta categoria
        default_extra_fees: Extra fees default para produtos desta categoria

    Returns:
        CategoryMappingOut schema
    """
    db = uow.db
    cat = db.get(Category, id_category)
    if not cat:
        raise NotFound(f"Category {id_category} not found")

    # Detetar transição de auto_import
    was_auto_import = cat.auto_import

    cat.id_ps_category = id_ps_category
    cat.ps_category_name = ps_category_name
    cat.auto_import = auto_import

    # Atualizar taxas default se fornecidas
    if default_ecotax is not None:
        cat.default_ecotax = default_ecotax
    if default_extra_fees is not None:
        cat.default_extra_fees = default_extra_fees

    # Se auto_import foi ativado agora, definir auto_import_since
    if auto_import and not was_auto_import:
        cat.auto_import_since = datetime.now(UTC)
    # Se auto_import foi desativado, limpar auto_import_since
    elif not auto_import and was_auto_import:
        cat.auto_import_since = None

    uow.commit()

    # Audit log
    AuditService(db).log_category_mapping(
        category_id=id_category,
        category_name=cat.name,
        ps_category_id=id_ps_category,
        ps_category_name=ps_category_name,
        auto_import=auto_import,
    )

    return CategoryMappingOut.model_validate(cat)
