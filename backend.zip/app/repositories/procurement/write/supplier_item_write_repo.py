# app/repositories/write/procurement/supplier_item_write_repo.py
from __future__ import annotations

import hashlib
from typing import Any
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import InvalidArgument
from app.models.supplier_item import SupplierItem


def _mk_fp(*parts: Any) -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class SupplierItemWriteRepository:
    def __init__(self, db: Session):
        self.db = db

    def upsert(
        self,
        *,
        id_feed: int,
        id_product: int,
        sku: str,
        price: str,
        stock: int,
        gtin: str | None,
        partnumber: str | None,
        id_feed_run: int,
    ) -> tuple[SupplierItem, bool, bool, str | None, int | None]:
        sku_norm = (sku or "").strip()
        if not sku_norm:
            raise InvalidArgument("SKU is empty")

        stmt = select(SupplierItem).where(
            SupplierItem.id_feed == id_feed,
            SupplierItem.sku == sku_norm,
        )
        item = self.db.scalar(stmt)

        created = False
        changed = False
        old_price: str | None = None
        old_stock: int | None = None

        new_fp = _mk_fp(id_feed, id_product, sku_norm, gtin, partnumber, price, stock)

        if item is None:
            item = SupplierItem(
                id_feed=id_feed,
                id_product=id_product,
                sku=sku_norm,
                gtin=gtin,
                partnumber=partnumber,
                price=price,
                stock=stock,
                fingerprint=new_fp,
                id_feed_run=id_feed_run,
            )
            self.db.add(item)
            created = True
        else:
            old_price = item.price
            old_stock = item.stock
            changed = (
                (old_price != price)
                or (old_stock != stock)
                or (item.id_product != id_product)
                or (item.gtin != gtin)
                or (item.partnumber != partnumber)
            )
            item.id_product = id_product
            item.gtin = gtin
            item.partnumber = partnumber
            item.price = price
            item.stock = stock
            item.id_feed_run = id_feed_run
            item.fingerprint = new_fp

        self.db.flush()
        return item, created, changed, old_price, old_stock
